#ifndef SIMDJSON_ICELAKE_ONDEMAND_H
#define SIMDJSON_ICELAKE_ONDEMAND_H

#include "simdjson/icelake/begin.h"
#include "simdjson/generic/ondemand/amalgamated.h"
#include "simdjson/icelake/end.h"

#endif // SIMDJSON_ICELAKE_ONDEMAND_H
